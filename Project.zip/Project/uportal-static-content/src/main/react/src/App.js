import PopularServices from './component/PopularServices'

function App() {
  return <PopularServices />
}

export default App;
